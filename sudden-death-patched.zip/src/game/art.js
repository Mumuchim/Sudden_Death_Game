/* Sudden Death — art.
   Every enemy gets its own silhouette. They all share the same structure
   (aura / mask / shadow) so one set of state animations drives all of them. */

import youImg from '../assets/portraits/you.png';
import miraImg from '../assets/portraits/mira.png';
import ayaImg from '../assets/portraits/aya.png';
import eliImg from '../assets/portraits/eli.png';
import noahImg from '../assets/portraits/noah.png';
import reyesImg from '../assets/portraits/reyes.png';

const pixelPortrait = (src, name) =>
  '<div class="pixel-portrait"><img src="' + src + '" alt="' + name + ' portrait" draggable="false"></div>';

const wrap = inner => '<svg viewBox="0 0 160 124" preserveAspectRatio="xMidYMid meet">' +
  '<ellipse class="aura" cx="80" cy="58" rx="44" ry="40"/>' +
  '<g class="mask">' + inner + '</g>' +
  '<g class="shadow"><ellipse cx="80" cy="112" rx="32" ry="5"/></g></svg>';

export const ENEMY_ART = {
  /* a hollowed-out vessel, horns, two slits */
  husk: wrap(
    '<path class="horns" d="M54 44 L43 12 L68 34 Z M106 44 L117 12 L92 34 Z"/>' +
    '<path class="shell" d="M80 20 C58 20 46 38 46 58 c0 23 14 41 34 46 20-5 34-23 34-46 0-20-12-38-34-38z"/>' +
    '<path class="eyes" d="M64 60 h13 M83 60 h13"/>' +
    '<path class="crack" d="M80 26 l-7 26 9 10 -5 22"/>'),

  /* outbreak variants: same inhuman family, different silhouettes for readable encounters */
  husk_sprinter: wrap(
    '<path class="horns" d="M56 44 L44 8 L71 34 Z M104 44 L116 8 L89 34 Z"/>' +
    '<path class="shell" d="M80 16 C62 16 50 34 50 56 c0 25 12 43 30 50 18-7 30-25 30-50 0-22-12-40-30-40z"/>' +
    '<path class="eyes" d="M62 57 h16 M82 57 h16"/>' +
    '<path class="crack" d="M73 24 l8 20 -10 18 12 18"/>'),

  husk_bruiser: wrap(
    '<path class="horns" d="M50 46 L34 18 L68 34 Z M110 46 L126 18 L92 34 Z"/>' +
    '<path class="shell" d="M80 24 C56 24 40 40 40 62 c0 21 15 37 40 44 25-7 40-23 40-44 0-22-16-38-40-38z"/>' +
    '<path class="eyes" d="M60 62 h14 M86 62 h14"/>' +
    '<path class="crack" d="M80 28 v24 l-13 14 15 14"/>'),

  husk_blackout: wrap(
    '<path class="horns" d="M58 42 L50 6 L73 33 Z M102 42 L110 6 L87 33 Z"/>' +
    '<path class="shell" d="M80 18 C60 18 48 35 48 58 c0 22 14 40 32 46 18-6 32-24 32-46 0-23-12-40-32-40z"/>' +
    '<path class="eyes" d="M63 59 h12 M85 59 h12"/>' +
    '<path class="crack" d="M80 20 l-4 18 8 10 -8 14 7 18"/>'),

  /* something long under the water */
  serpent: wrap(
    '<path class="shell" d="M22 84 c18 0 20-16 36-16 s18 16 34 16 20-18 34-18 c8 0 12 4 12 4"/>' +
    '<path class="shell" d="M96 36 c14 0 22 10 22 20 0 12-10 20-22 20 -14 0-22-9-22-20 0-11 9-20 22-20z"/>' +
    '<path class="eyes" d="M104 52 h10"/>' +
    '<path class="horns" d="M96 38 L86 18 L110 32 Z"/>' +
    '<path class="crack" d="M98 44 l-4 14 8 6"/>'),

  /* a door that learned to stand up */
  warden: wrap(
    '<path class="shell" d="M62 22 h36 v70 h-36 z"/>' +
    '<path class="horns" d="M62 22 L46 8 L62 38 Z M98 22 L114 8 L98 38 Z"/>' +
    '<path class="shell" d="M20 56 h42 M98 56 h42"/>' +
    '<path class="eyes" d="M70 46 h8 M82 46 h8"/>' +
    '<path class="crack" d="M80 24 v66"/>'),

  /* the shape three hundred years of holding makes */
  keeper: wrap(
    '<path class="shell" d="M80 14 C60 14 50 32 50 54 c0 26 12 44 30 52 18-8 30-26 30-52 0-22-10-40-30-40z"/>' +
    '<path class="horns" d="M50 44 L34 10 L70 30 Z M110 44 L126 10 L90 30 Z"/>' +
    '<path class="eyes" d="M68 54 l10 8 M92 54 l-10 8"/>' +
    '<path class="chains" d="M30 76 h100 M36 88 h88"/>' +
    '<path class="crack" d="M80 20 l-8 34 10 12 -6 28"/>'),

  /* someone from another world, wearing your flaw */
  apostle: wrap(
    '<path class="horns" d="M56 42 L46 14 L70 34 Z M104 42 L114 14 L90 34 Z"/>' +
    '<path class="shell" d="M80 20 C59 20 48 37 48 57 c0 22 13 39 32 45 19-6 32-23 32-45 0-20-11-37-32-37z"/>' +
    '<path class="eyes" d="M65 58 h12 M83 58 h12"/>' +
    '<path class="shell" d="M64 78 q16 8 32 0"/>' +
    '<path class="crack" d="M62 30 l4 -8"/>'),

  /* the fourth one */
  four: wrap(
    '<path class="horns" d="M56 42 L46 14 L70 34 Z M104 42 L114 14 L90 34 Z"/>' +
    '<path class="shell" d="M80 20 C59 20 48 37 48 57 c0 22 13 39 32 45 19-6 32-23 32-45 0-20-11-37-32-37z"/>' +
    '<path class="eyes" d="M65 58 h12 M83 58 h12"/>' +
    '<path class="numeral" d="M70 76 v10 M76 76 v10 M82 76 v10 M88 72 v14"/>'),

  /* she is not a monster and the game will not pretend she is */
  radiance: wrap(
    '<g class="rays"><path class="horns" d="M80 4 v18 M80 108 v-18 M18 58 h18 M142 58 h-18 M36 20 l13 13 M124 20 l-13 13 M36 96 l13-13 M124 96 l-13-13"/></g>' +
    '<circle class="shell" cx="80" cy="58" r="30"/>' +
    '<path class="eyes" d="M66 52 q14 -10 28 0"/>' +
    '<path class="eyes" d="M70 66 q10 8 20 0"/>' +
    '<circle class="crack" cx="80" cy="58" r="16"/>'),

  /* the regressor. a mask worn thin by being worn too many times. */
  hollow: wrap(
    '<path class="shell" d="M80 20 C60 20 49 38 49 58 c0 22 13 39 31 45 18-6 31-23 31-45 0-20-11-38-31-38z"/>' +
    '<path class="eyes" d="M66 58 h12 M84 58 h12"/>' +
    '<path class="crack" d="M80 22 l-6 20 7 8 -4 16 M62 40 l-5 -6 M100 44 l6 -5 M70 76 l-4 10 M92 74 l5 9"/>' +
    '<path class="chains" d="M50 92 q30 10 60 0"/>'),

  /* each apostle is a person, and the art says so: one soft edge */
  apostle_tallow: wrap(
    '<path class="horns" d="M58 42 L50 16 L70 34 Z M102 42 L110 16 L90 34 Z"/>' +
    '<path class="shell" d="M80 20 C59 20 48 37 48 57 c0 22 13 39 32 45 19-6 32-23 32-45 0-20-11-37-32-37z"/>' +
    '<path class="eyes" d="M65 56 h12 M83 56 h12"/>' +
    '<path class="smile" d="M64 74 q16 12 32 0"/>'),
  apostle_quill: wrap(
    '<path class="shell" d="M80 18 C58 18 47 36 47 58 c0 23 14 40 33 46 19-6 33-23 33-46 0-22-11-40-33-40z"/>' +
    '<path class="eyes" d="M64 56 h13 M83 56 h13"/>' +
    '<path class="chains" d="M56 70 h48"/>' +
    '<path class="horns" d="M80 18 L80 6 M64 22 L58 10 M96 22 L102 10"/>'),
  apostle_bit: wrap(
    '<path class="shell" d="M80 26 C62 26 52 42 52 60 c0 20 12 35 28 40 16-5 28-20 28-40 0-18-10-34-28-34z"/>' +
    '<path class="eyes" d="M67 60 h11 M82 60 h11"/>' +
    '<path class="horns" d="M60 46 L52 24 L72 40 Z"/>' +
    '<path class="crack" d="M80 30 l-5 18 6 6"/>'),

  /* a warm, funny, helpful man */
  mangod: wrap(
    '<circle class="shell" cx="80" cy="56" r="32"/>' +
    '<path class="eyes" d="M66 46 q5 -7 10 0 M84 46 q5 -7 10 0"/>' +
    '<path class="smile" d="M62 64 q18 20 36 0"/>' +
    '<path class="crack" d="M80 24 v-8 M62 30 l-5 -6 M98 30 l5 -6"/>')
};

/* Small line portraits, shown once when a character matters. */
const face = inner => '<svg viewBox="0 0 80 80" preserveAspectRatio="xMidYMid meet"><g class="por">' + inner + '</g></svg>';

export const PORTRAIT = {
  you: pixelPortrait(youImg, 'You'),
  mira: pixelPortrait(miraImg, 'Mira'),
  aya: pixelPortrait(ayaImg, 'Aya'),
  eli: pixelPortrait(eliImg, 'Eli'),
  noah: pixelPortrait(noahImg, 'Noah'),
  reyes: pixelPortrait(reyesImg, 'Ms. Reyes'),
  ally: face(
    '<path d="M40 14 C28 14 22 25 22 36 c0 15 8 25 18 29 10-4 18-14 18-29 0-11-6-22-18-22z"/>' +
    '<path d="M31 35 h7 M42 35 h7"/>' +
    '<path d="M33 48 q7 4 14 0"/>' +
    '<path d="M16 70 q24 -12 48 0"/>'),
  mangod: face(
    '<circle cx="40" cy="36" r="22"/>' +
    '<path d="M31 30 q4 -6 8 0 M41 30 q4 -6 8 0"/>' +
    '<path d="M28 42 q12 14 24 0"/>' +
    '<path d="M40 10 v-6 M22 16 l-4 -5 M58 16 l4 -5"/>'),
  four: face(
    '<path d="M40 14 C28 14 22 26 22 37 c0 14 8 24 18 28 10-4 18-14 18-28 0-11-6-23-18-23z"/>' +
    '<path d="M30 36 h8 M42 36 h8"/>' +
    '<path d="M30 56 v8 M35 56 v8 M40 56 v8 M46 52 v12"/>'),
  sealed: face(
    '<path d="M40 8 C27 8 20 22 20 38 c0 18 8 30 20 34 12-4 20-16 20-34 0-16-7-30-20-30z"/>' +
    '<path d="M31 34 l7 7 M49 34 l-7 7"/>' +
    '<path d="M12 52 h56 M16 62 h48"/>'),
  bright: face(
    '<circle cx="40" cy="38" r="18"/>' +
    '<path d="M40 6 v10 M40 70 v-10 M8 38 h10 M72 38 h-10 M17 15 l7 7 M63 15 l-7 7 M17 61 l7 -7 M63 61 l-7 -7"/>' +
    '<path d="M31 34 q9 -6 18 0"/>'),
  companion: face(
    '<path d="M40 16 C29 16 24 26 24 36 c0 14 7 23 16 27 9-4 16-13 16-27 0-10-5-20-16-20z"/>' +
    '<path d="M32 34 h6 M43 34 h6"/>' +
    '<path d="M34 47 q6 4 12 0"/>' +
    '<path d="M22 66 q18 -10 36 0"/>'),
  ren: face(
    '<path d="M40 14 C29 14 22 26 22 38 c0 15 8 25 18 29 10-4 18-14 18-29 0-12-7-24-18-24z"/>' +
    '<path d="M30 36 h8 M42 36 h8"/>' +
    '<path d="M32 50 q8 3 16 -1"/>' +
    '<path d="M20 22 q20 -10 40 0"/>'),
  tallow: face(
    '<path d="M40 14 C28 14 22 26 22 37 c0 14 8 24 18 28 10-4 18-14 18-28 0-11-6-23-18-23z"/>' +
    '<path d="M30 34 h8 M42 34 h8"/>' +
    '<path d="M31 47 q9 8 18 0"/>' +
    '<path d="M18 68 q22 -12 44 0"/>' +
    '<path d="M14 30 l6 4 M66 30 l-6 4"/>'),
  quill: face(
    '<path d="M40 12 C27 12 21 25 21 38 c0 16 8 27 19 31 11-4 19-15 19-31 0-13-6-26-19-26z"/>' +
    '<path d="M29 36 h9 M42 36 h9"/>' +
    '<path d="M33 52 h14"/>' +
    '<path d="M16 24 q24 -12 48 0"/>' +
    '<path d="M58 60 l10 -14"/>'),
  bit: face(
    '<path d="M40 20 C30 20 25 30 25 40 c0 13 6 21 15 24 9-3 15-11 15-24 0-10-5-20-15-20z"/>' +
    '<path d="M32 39 h6 M43 39 h6"/>' +
    '<path d="M35 50 q5 4 10 0"/>' +
    '<path d="M62 8 v62"/>'),
  mumu: face(
    '<path d="M40 10 C26 10 19 24 19 38 c0 17 9 28 21 32 12-4 21-15 21-32 0-14-7-28-21-28z"/>' +
    '<path d="M28 36 h10 M43 36 h10"/>' +
    '<path d="M40 14 l-5 14 6 6 -4 12"/>' +
    '<path d="M22 60 q18 8 36 0"/>'),
  deep: face(
    '<circle cx="40" cy="40" r="26" opacity=".35"/>' +
    '<circle cx="40" cy="40" r="17" opacity=".6"/>' +
    '<circle cx="40" cy="40" r="7"/>')
};
